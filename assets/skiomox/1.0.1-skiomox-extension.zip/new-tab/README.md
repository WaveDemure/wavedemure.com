# Skiovox Helper -- the helper extension for the Skiovox exploit

**Installation steps can be seen at the "stage 3" section on [skiovox.com](https://skiovox.com)**

This extension:

- Fixes most shortcut functionality within the exploit
- Allows for resizing and dragging of windows
- Makes it easier to add Google accounts and use the Web Store within the exploit

*Note: You can exit fullscreen videos by pressing ctrl+T after you've set up the shortcuts*

<img src="https://github.com/bypassiwastaken/skiovox-helper/assets/144500273/baa94258-e1e0-46aa-831b-6667c39c5374" width="500">